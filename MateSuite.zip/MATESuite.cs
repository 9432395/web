﻿#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.Indicators.MATE.MGI;
using NinjaTrader.NinjaScript.Indicators.MATE.VWAP;
using NinjaTrader.NinjaScript.Indicators.MATE.Profiles;
using NinjaTrader.NinjaScript.Indicators.MATE.OrderFlow;
using NinjaTrader.NinjaScript.Indicators.MATE.Tools;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private AnchoredVolumeProfile[] cacheAnchoredVolumeProfile;
		private AuctionContext[] cacheAuctionContext;
		private BigTradesInstitutional[] cacheBigTradesInstitutional;
		private DailyMGI[] cacheDailyMGI;
		private DailyVWAP[] cacheDailyVWAP;
		private DeltaProfile[] cacheDeltaProfile;
		private DeltaSuite[] cacheDeltaSuite;
		private FixedRangeVolumeProfile[] cacheFixedRangeVolumeProfile;
		private FootprintOrderFlow[] cacheFootprintOrderFlow;
		private LagSentinel[] cacheLagSentinel;
		private LiquidityHeatmap[] cacheLiquidityHeatmap;
		private MonthlyMGI[] cacheMonthlyMGI;
		private MonthlyVWAP[] cacheMonthlyVWAP;
		private QuarterlyMGI[] cacheQuarterlyMGI;
		private QuarterlyVWAP[] cacheQuarterlyVWAP;
		private SessionTpoVolumeProfile[] cacheSessionTpoVolumeProfile;
		private WeeklyMGI[] cacheWeeklyMGI;
		private WeeklyVWAP[] cacheWeeklyVWAP;
		private YearlyMGI[] cacheYearlyMGI;
		private YearlyVWAP[] cacheYearlyVWAP;

		
		public AnchoredVolumeProfile AnchoredVolumeProfile()
		{
			return AnchoredVolumeProfile(Input);
		}

		public AuctionContext AuctionContext(string rthTemplateName, bool manualTimesInEt, string rthStartText, string rthEndText, int ibMinutes, bool onStartsAtGlobexReopen, string globexOpenText, int lookback, bool useMedian, int minOnMinutes, int minRthMinutes, bool enableRotations, AcxRotationSequence rotationSequence, int rotationReversalTicks, bool showRotationDetail, bool enableDelta, bool enableCsvLog, bool enableAuditLog, bool showDataQuality, int panelFontSize, AcxPanelSide panelSide, bool showOvernightRange, bool showInitialBalanceRange, bool showRthRange, bool showEthRange, bool showRthVolume, bool showRelativeVolume, bool showOvernightVolume, bool showWeeklyRange, bool showWeeklyVolume, int weeksLookback, bool showOvernightInventory, bool showOvernightDelta, bool showIbExtensions, int panelRightMargin, int panelTopMargin)
		{
			return AuctionContext(Input, rthTemplateName, manualTimesInEt, rthStartText, rthEndText, ibMinutes, onStartsAtGlobexReopen, globexOpenText, lookback, useMedian, minOnMinutes, minRthMinutes, enableRotations, rotationSequence, rotationReversalTicks, showRotationDetail, enableDelta, enableCsvLog, enableAuditLog, showDataQuality, panelFontSize, panelSide, showOvernightRange, showInitialBalanceRange, showRthRange, showEthRange, showRthVolume, showRelativeVolume, showOvernightVolume, showWeeklyRange, showWeeklyVolume, weeksLookback, showOvernightInventory, showOvernightDelta, showIbExtensions, panelRightMargin, panelTopMargin);
		}

		public BigTradesInstitutional BigTradesInstitutional()
		{
			return BigTradesInstitutional(Input);
		}

		public DailyMGI DailyMGI(TimeSpan rTHStartTime, TimeSpan rTHEndTime, TimeSpan overnightStartTime, TimeSpan overnightEndTime, TimeSpan eTHStartTime, TimeSpan eTHEndTime, int initialBalanceMinutes, int daysOfHistory, bool showPreviousDays, bool showOvernightRange, bool showInitialBalance, bool showIBExtensions, bool showPriorDayRTH, bool showPriorDayETH, bool showPriorDayProfile, bool showPriorETHProfile, bool showONProfile, double valueAreaPercent, bool showHalfGap, double iBExtensionMultiplier0, double iBExtensionMultiplier1, double iBExtensionMultiplier2, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			return DailyMGI(Input, rTHStartTime, rTHEndTime, overnightStartTime, overnightEndTime, eTHStartTime, eTHEndTime, initialBalanceMinutes, daysOfHistory, showPreviousDays, showOvernightRange, showInitialBalance, showIBExtensions, showPriorDayRTH, showPriorDayETH, showPriorDayProfile, showPriorETHProfile, showONProfile, valueAreaPercent, showHalfGap, iBExtensionMultiplier0, iBExtensionMultiplier1, iBExtensionMultiplier2, showLabels, showValues, labelDistance, lineWidth);
		}

		public DailyVWAP DailyVWAP(TimeSpan rTHStartTime, TimeSpan rTHEndTime, TimeSpan eTHStartTime, TimeSpan eTHEndTime)
		{
			return DailyVWAP(Input, rTHStartTime, rTHEndTime, eTHStartTime, eTHEndTime);
		}

		public DeltaProfile DeltaProfile()
		{
			return DeltaProfile(Input);
		}

		public DeltaSuite DeltaSuite(double bigTradeThreshold)
		{
			return DeltaSuite(Input, bigTradeThreshold);
		}

		public FixedRangeVolumeProfile FixedRangeVolumeProfile(int ticksPerRow)
		{
			return FixedRangeVolumeProfile(Input, ticksPerRow);
		}

		public FootprintOrderFlow FootprintOrderFlow()
		{
			return FootprintOrderFlow(Input);
		}

		public LagSentinel LagSentinel(LagSentinelLocation location, int hOffset, int vOffset, double lagThresholdSeconds, double staleQuoteSeconds, double orderAckThresholdSeconds, double uiLagThresholdSeconds, int fontSize, bool alertOnDegraded, string alertSound)
		{
			return LagSentinel(Input, location, hOffset, vOffset, lagThresholdSeconds, staleQuoteSeconds, orderAckThresholdSeconds, uiLagThresholdSeconds, fontSize, alertOnDegraded, alertSound);
		}

		public LiquidityHeatmap LiquidityHeatmap(int rTHStartHHMM, bool bookmapMode, int snapshotIntervalSeconds, int maxHistoryMinutes, double maxHeatOpacity, double minVisibleOpacity, int heatmapMaxReference, bool filterSmallLiquidity, int minLiquidityThreshold, bool showActiveLiquidityExtension, bool showLastPriceLine, bool showHeatScale, bool showBestBidAskLines, bool showVolumeDots, int minDotVolume, int dotVolumeReference, int dotMaxRadius, double dotOpacity, bool showOrderBookPanel, int orderBookPanelWidth, bool showAbsorptionMarkers, int absorptionMinContracts, int absorptionWindowTicks, double icebergRatioThreshold, bool showPulledWallMarkers, int pulledWallMinContracts, int pulledWallMaxExecutedPct, double brokenMarkerFade, float absorptionMaxWidth, double absorptionMinOpacity, int refreshIntervalMs, int cleanupIntervalSeconds, int staleLevelMinutes, bool enableTelemetryLog)
		{
			return LiquidityHeatmap(Input, rTHStartHHMM, bookmapMode, snapshotIntervalSeconds, maxHistoryMinutes, maxHeatOpacity, minVisibleOpacity, heatmapMaxReference, filterSmallLiquidity, minLiquidityThreshold, showActiveLiquidityExtension, showLastPriceLine, showHeatScale, showBestBidAskLines, showVolumeDots, minDotVolume, dotVolumeReference, dotMaxRadius, dotOpacity, showOrderBookPanel, orderBookPanelWidth, showAbsorptionMarkers, absorptionMinContracts, absorptionWindowTicks, icebergRatioThreshold, showPulledWallMarkers, pulledWallMinContracts, pulledWallMaxExecutedPct, brokenMarkerFade, absorptionMaxWidth, absorptionMinOpacity, refreshIntervalMs, cleanupIntervalSeconds, staleLevelMinutes, enableTelemetryLog);
		}

		public MonthlyMGI MonthlyMGI(TimeSpan sessionStartTime, int monthsOfHistory, bool showPreviousMonths, bool showPriorMonthLevels, bool showPriorMonthProfile, double valueAreaPercent, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			return MonthlyMGI(Input, sessionStartTime, monthsOfHistory, showPreviousMonths, showPriorMonthLevels, showPriorMonthProfile, valueAreaPercent, showLabels, showValues, labelDistance, lineWidth);
		}

		public MonthlyVWAP MonthlyVWAP(TimeSpan sessionStartTime)
		{
			return MonthlyVWAP(Input, sessionStartTime);
		}

		public QuarterlyMGI QuarterlyMGI(TimeSpan sessionStartTime, int quartersOfHistory, bool showPreviousQuarters, bool showPriorQuarterLevels, bool showPriorQuarterProfile, double valueAreaPercent, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			return QuarterlyMGI(Input, sessionStartTime, quartersOfHistory, showPreviousQuarters, showPriorQuarterLevels, showPriorQuarterProfile, valueAreaPercent, showLabels, showValues, labelDistance, lineWidth);
		}

		public QuarterlyVWAP QuarterlyVWAP(TimeSpan sessionStartTime)
		{
			return QuarterlyVWAP(Input, sessionStartTime);
		}

		public SessionTpoVolumeProfile SessionTpoVolumeProfile(int ticksPerRow, int bracketMinutes, double valueAreaPercent, int minTailRows)
		{
			return SessionTpoVolumeProfile(Input, ticksPerRow, bracketMinutes, valueAreaPercent, minTailRows);
		}

		public WeeklyMGI WeeklyMGI(TimeSpan weeklyOpenTime, TimeSpan weeklyCloseTime, int weeksOfHistory, bool showPreviousWeeks, bool showPriorWeekLevels, bool showPriorWeekProfile, double valueAreaPercent, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			return WeeklyMGI(Input, weeklyOpenTime, weeklyCloseTime, weeksOfHistory, showPreviousWeeks, showPriorWeekLevels, showPriorWeekProfile, valueAreaPercent, showLabels, showValues, labelDistance, lineWidth);
		}

		public WeeklyVWAP WeeklyVWAP(TimeSpan weeklyOpenTime, TimeSpan weeklyCloseTime)
		{
			return WeeklyVWAP(Input, weeklyOpenTime, weeklyCloseTime);
		}

		public YearlyMGI YearlyMGI(TimeSpan sessionStartTime, int yearsOfHistory, bool showPreviousYears, bool showPriorYearLevels, bool showPriorYearProfile, double valueAreaPercent, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			return YearlyMGI(Input, sessionStartTime, yearsOfHistory, showPreviousYears, showPriorYearLevels, showPriorYearProfile, valueAreaPercent, showLabels, showValues, labelDistance, lineWidth);
		}

		public YearlyVWAP YearlyVWAP(TimeSpan sessionStartTime)
		{
			return YearlyVWAP(Input, sessionStartTime);
		}


		
		public AnchoredVolumeProfile AnchoredVolumeProfile(ISeries<double> input)
		{
			if (cacheAnchoredVolumeProfile != null)
				for (int idx = 0; idx < cacheAnchoredVolumeProfile.Length; idx++)
					if ( cacheAnchoredVolumeProfile[idx].EqualsInput(input))
						return cacheAnchoredVolumeProfile[idx];
			return CacheIndicator<AnchoredVolumeProfile>(new AnchoredVolumeProfile(), input, ref cacheAnchoredVolumeProfile);
		}

		public AuctionContext AuctionContext(ISeries<double> input, string rthTemplateName, bool manualTimesInEt, string rthStartText, string rthEndText, int ibMinutes, bool onStartsAtGlobexReopen, string globexOpenText, int lookback, bool useMedian, int minOnMinutes, int minRthMinutes, bool enableRotations, AcxRotationSequence rotationSequence, int rotationReversalTicks, bool showRotationDetail, bool enableDelta, bool enableCsvLog, bool enableAuditLog, bool showDataQuality, int panelFontSize, AcxPanelSide panelSide, bool showOvernightRange, bool showInitialBalanceRange, bool showRthRange, bool showEthRange, bool showRthVolume, bool showRelativeVolume, bool showOvernightVolume, bool showWeeklyRange, bool showWeeklyVolume, int weeksLookback, bool showOvernightInventory, bool showOvernightDelta, bool showIbExtensions, int panelRightMargin, int panelTopMargin)
		{
			if (cacheAuctionContext != null)
				for (int idx = 0; idx < cacheAuctionContext.Length; idx++)
					if (cacheAuctionContext[idx].RthTemplateName == rthTemplateName && cacheAuctionContext[idx].ManualTimesInEt == manualTimesInEt && cacheAuctionContext[idx].RthStartText == rthStartText && cacheAuctionContext[idx].RthEndText == rthEndText && cacheAuctionContext[idx].IbMinutes == ibMinutes && cacheAuctionContext[idx].OnStartsAtGlobexReopen == onStartsAtGlobexReopen && cacheAuctionContext[idx].GlobexOpenText == globexOpenText && cacheAuctionContext[idx].Lookback == lookback && cacheAuctionContext[idx].UseMedian == useMedian && cacheAuctionContext[idx].MinOnMinutes == minOnMinutes && cacheAuctionContext[idx].MinRthMinutes == minRthMinutes && cacheAuctionContext[idx].EnableRotations == enableRotations && cacheAuctionContext[idx].RotationSequence == rotationSequence && cacheAuctionContext[idx].RotationReversalTicks == rotationReversalTicks && cacheAuctionContext[idx].ShowRotationDetail == showRotationDetail && cacheAuctionContext[idx].EnableDelta == enableDelta && cacheAuctionContext[idx].EnableCsvLog == enableCsvLog && cacheAuctionContext[idx].EnableAuditLog == enableAuditLog && cacheAuctionContext[idx].ShowDataQuality == showDataQuality && cacheAuctionContext[idx].PanelFontSize == panelFontSize && cacheAuctionContext[idx].PanelSide == panelSide && cacheAuctionContext[idx].ShowOvernightRange == showOvernightRange && cacheAuctionContext[idx].ShowInitialBalanceRange == showInitialBalanceRange && cacheAuctionContext[idx].ShowRthRange == showRthRange && cacheAuctionContext[idx].ShowEthRange == showEthRange && cacheAuctionContext[idx].ShowRthVolume == showRthVolume && cacheAuctionContext[idx].ShowRelativeVolume == showRelativeVolume && cacheAuctionContext[idx].ShowOvernightVolume == showOvernightVolume && cacheAuctionContext[idx].ShowWeeklyRange == showWeeklyRange && cacheAuctionContext[idx].ShowWeeklyVolume == showWeeklyVolume && cacheAuctionContext[idx].WeeksLookback == weeksLookback && cacheAuctionContext[idx].ShowOvernightInventory == showOvernightInventory && cacheAuctionContext[idx].ShowOvernightDelta == showOvernightDelta && cacheAuctionContext[idx].ShowIbExtensions == showIbExtensions && cacheAuctionContext[idx].PanelRightMargin == panelRightMargin && cacheAuctionContext[idx].PanelTopMargin == panelTopMargin && cacheAuctionContext[idx].EqualsInput(input))
						return cacheAuctionContext[idx];
			return CacheIndicator<AuctionContext>(new AuctionContext(){ RthTemplateName = rthTemplateName, ManualTimesInEt = manualTimesInEt, RthStartText = rthStartText, RthEndText = rthEndText, IbMinutes = ibMinutes, OnStartsAtGlobexReopen = onStartsAtGlobexReopen, GlobexOpenText = globexOpenText, Lookback = lookback, UseMedian = useMedian, MinOnMinutes = minOnMinutes, MinRthMinutes = minRthMinutes, EnableRotations = enableRotations, RotationSequence = rotationSequence, RotationReversalTicks = rotationReversalTicks, ShowRotationDetail = showRotationDetail, EnableDelta = enableDelta, EnableCsvLog = enableCsvLog, EnableAuditLog = enableAuditLog, ShowDataQuality = showDataQuality, PanelFontSize = panelFontSize, PanelSide = panelSide, ShowOvernightRange = showOvernightRange, ShowInitialBalanceRange = showInitialBalanceRange, ShowRthRange = showRthRange, ShowEthRange = showEthRange, ShowRthVolume = showRthVolume, ShowRelativeVolume = showRelativeVolume, ShowOvernightVolume = showOvernightVolume, ShowWeeklyRange = showWeeklyRange, ShowWeeklyVolume = showWeeklyVolume, WeeksLookback = weeksLookback, ShowOvernightInventory = showOvernightInventory, ShowOvernightDelta = showOvernightDelta, ShowIbExtensions = showIbExtensions, PanelRightMargin = panelRightMargin, PanelTopMargin = panelTopMargin }, input, ref cacheAuctionContext);
		}

		public BigTradesInstitutional BigTradesInstitutional(ISeries<double> input)
		{
			if (cacheBigTradesInstitutional != null)
				for (int idx = 0; idx < cacheBigTradesInstitutional.Length; idx++)
					if ( cacheBigTradesInstitutional[idx].EqualsInput(input))
						return cacheBigTradesInstitutional[idx];
			return CacheIndicator<BigTradesInstitutional>(new BigTradesInstitutional(), input, ref cacheBigTradesInstitutional);
		}

		public DailyMGI DailyMGI(ISeries<double> input, TimeSpan rTHStartTime, TimeSpan rTHEndTime, TimeSpan overnightStartTime, TimeSpan overnightEndTime, TimeSpan eTHStartTime, TimeSpan eTHEndTime, int initialBalanceMinutes, int daysOfHistory, bool showPreviousDays, bool showOvernightRange, bool showInitialBalance, bool showIBExtensions, bool showPriorDayRTH, bool showPriorDayETH, bool showPriorDayProfile, bool showPriorETHProfile, bool showONProfile, double valueAreaPercent, bool showHalfGap, double iBExtensionMultiplier0, double iBExtensionMultiplier1, double iBExtensionMultiplier2, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			if (cacheDailyMGI != null)
				for (int idx = 0; idx < cacheDailyMGI.Length; idx++)
					if (cacheDailyMGI[idx].RTHStartTime == rTHStartTime && cacheDailyMGI[idx].RTHEndTime == rTHEndTime && cacheDailyMGI[idx].OvernightStartTime == overnightStartTime && cacheDailyMGI[idx].OvernightEndTime == overnightEndTime && cacheDailyMGI[idx].ETHStartTime == eTHStartTime && cacheDailyMGI[idx].ETHEndTime == eTHEndTime && cacheDailyMGI[idx].InitialBalanceMinutes == initialBalanceMinutes && cacheDailyMGI[idx].DaysOfHistory == daysOfHistory && cacheDailyMGI[idx].ShowPreviousDays == showPreviousDays && cacheDailyMGI[idx].ShowOvernightRange == showOvernightRange && cacheDailyMGI[idx].ShowInitialBalance == showInitialBalance && cacheDailyMGI[idx].ShowIBExtensions == showIBExtensions && cacheDailyMGI[idx].ShowPriorDayRTH == showPriorDayRTH && cacheDailyMGI[idx].ShowPriorDayETH == showPriorDayETH && cacheDailyMGI[idx].ShowPriorDayProfile == showPriorDayProfile && cacheDailyMGI[idx].ShowPriorETHProfile == showPriorETHProfile && cacheDailyMGI[idx].ShowONProfile == showONProfile && cacheDailyMGI[idx].ValueAreaPercent == valueAreaPercent && cacheDailyMGI[idx].ShowHalfGap == showHalfGap && cacheDailyMGI[idx].IBExtensionMultiplier0 == iBExtensionMultiplier0 && cacheDailyMGI[idx].IBExtensionMultiplier1 == iBExtensionMultiplier1 && cacheDailyMGI[idx].IBExtensionMultiplier2 == iBExtensionMultiplier2 && cacheDailyMGI[idx].ShowLabels == showLabels && cacheDailyMGI[idx].ShowValues == showValues && cacheDailyMGI[idx].LabelDistance == labelDistance && cacheDailyMGI[idx].LineWidth == lineWidth && cacheDailyMGI[idx].EqualsInput(input))
						return cacheDailyMGI[idx];
			return CacheIndicator<DailyMGI>(new DailyMGI(){ RTHStartTime = rTHStartTime, RTHEndTime = rTHEndTime, OvernightStartTime = overnightStartTime, OvernightEndTime = overnightEndTime, ETHStartTime = eTHStartTime, ETHEndTime = eTHEndTime, InitialBalanceMinutes = initialBalanceMinutes, DaysOfHistory = daysOfHistory, ShowPreviousDays = showPreviousDays, ShowOvernightRange = showOvernightRange, ShowInitialBalance = showInitialBalance, ShowIBExtensions = showIBExtensions, ShowPriorDayRTH = showPriorDayRTH, ShowPriorDayETH = showPriorDayETH, ShowPriorDayProfile = showPriorDayProfile, ShowPriorETHProfile = showPriorETHProfile, ShowONProfile = showONProfile, ValueAreaPercent = valueAreaPercent, ShowHalfGap = showHalfGap, IBExtensionMultiplier0 = iBExtensionMultiplier0, IBExtensionMultiplier1 = iBExtensionMultiplier1, IBExtensionMultiplier2 = iBExtensionMultiplier2, ShowLabels = showLabels, ShowValues = showValues, LabelDistance = labelDistance, LineWidth = lineWidth }, input, ref cacheDailyMGI);
		}

		public DailyVWAP DailyVWAP(ISeries<double> input, TimeSpan rTHStartTime, TimeSpan rTHEndTime, TimeSpan eTHStartTime, TimeSpan eTHEndTime)
		{
			if (cacheDailyVWAP != null)
				for (int idx = 0; idx < cacheDailyVWAP.Length; idx++)
					if (cacheDailyVWAP[idx].RTHStartTime == rTHStartTime && cacheDailyVWAP[idx].RTHEndTime == rTHEndTime && cacheDailyVWAP[idx].ETHStartTime == eTHStartTime && cacheDailyVWAP[idx].ETHEndTime == eTHEndTime && cacheDailyVWAP[idx].EqualsInput(input))
						return cacheDailyVWAP[idx];
			return CacheIndicator<DailyVWAP>(new DailyVWAP(){ RTHStartTime = rTHStartTime, RTHEndTime = rTHEndTime, ETHStartTime = eTHStartTime, ETHEndTime = eTHEndTime }, input, ref cacheDailyVWAP);
		}

		public DeltaProfile DeltaProfile(ISeries<double> input)
		{
			if (cacheDeltaProfile != null)
				for (int idx = 0; idx < cacheDeltaProfile.Length; idx++)
					if ( cacheDeltaProfile[idx].EqualsInput(input))
						return cacheDeltaProfile[idx];
			return CacheIndicator<DeltaProfile>(new DeltaProfile(), input, ref cacheDeltaProfile);
		}

		public DeltaSuite DeltaSuite(ISeries<double> input, double bigTradeThreshold)
		{
			if (cacheDeltaSuite != null)
				for (int idx = 0; idx < cacheDeltaSuite.Length; idx++)
					if (cacheDeltaSuite[idx].BigTradeThreshold == bigTradeThreshold && cacheDeltaSuite[idx].EqualsInput(input))
						return cacheDeltaSuite[idx];
			return CacheIndicator<DeltaSuite>(new DeltaSuite(){ BigTradeThreshold = bigTradeThreshold }, input, ref cacheDeltaSuite);
		}

		public FixedRangeVolumeProfile FixedRangeVolumeProfile(ISeries<double> input, int ticksPerRow)
		{
			if (cacheFixedRangeVolumeProfile != null)
				for (int idx = 0; idx < cacheFixedRangeVolumeProfile.Length; idx++)
					if (cacheFixedRangeVolumeProfile[idx].TicksPerRow == ticksPerRow && cacheFixedRangeVolumeProfile[idx].EqualsInput(input))
						return cacheFixedRangeVolumeProfile[idx];
			return CacheIndicator<FixedRangeVolumeProfile>(new FixedRangeVolumeProfile(){ TicksPerRow = ticksPerRow }, input, ref cacheFixedRangeVolumeProfile);
		}

		public FootprintOrderFlow FootprintOrderFlow(ISeries<double> input)
		{
			if (cacheFootprintOrderFlow != null)
				for (int idx = 0; idx < cacheFootprintOrderFlow.Length; idx++)
					if ( cacheFootprintOrderFlow[idx].EqualsInput(input))
						return cacheFootprintOrderFlow[idx];
			return CacheIndicator<FootprintOrderFlow>(new FootprintOrderFlow(), input, ref cacheFootprintOrderFlow);
		}

		public LagSentinel LagSentinel(ISeries<double> input, LagSentinelLocation location, int hOffset, int vOffset, double lagThresholdSeconds, double staleQuoteSeconds, double orderAckThresholdSeconds, double uiLagThresholdSeconds, int fontSize, bool alertOnDegraded, string alertSound)
		{
			if (cacheLagSentinel != null)
				for (int idx = 0; idx < cacheLagSentinel.Length; idx++)
					if (cacheLagSentinel[idx].Location == location && cacheLagSentinel[idx].HOffset == hOffset && cacheLagSentinel[idx].VOffset == vOffset && cacheLagSentinel[idx].LagThresholdSeconds == lagThresholdSeconds && cacheLagSentinel[idx].StaleQuoteSeconds == staleQuoteSeconds && cacheLagSentinel[idx].OrderAckThresholdSeconds == orderAckThresholdSeconds && cacheLagSentinel[idx].UiLagThresholdSeconds == uiLagThresholdSeconds && cacheLagSentinel[idx].FontSize == fontSize && cacheLagSentinel[idx].AlertOnDegraded == alertOnDegraded && cacheLagSentinel[idx].AlertSound == alertSound && cacheLagSentinel[idx].EqualsInput(input))
						return cacheLagSentinel[idx];
			return CacheIndicator<LagSentinel>(new LagSentinel(){ Location = location, HOffset = hOffset, VOffset = vOffset, LagThresholdSeconds = lagThresholdSeconds, StaleQuoteSeconds = staleQuoteSeconds, OrderAckThresholdSeconds = orderAckThresholdSeconds, UiLagThresholdSeconds = uiLagThresholdSeconds, FontSize = fontSize, AlertOnDegraded = alertOnDegraded, AlertSound = alertSound }, input, ref cacheLagSentinel);
		}

		public LiquidityHeatmap LiquidityHeatmap(ISeries<double> input, int rTHStartHHMM, bool bookmapMode, int snapshotIntervalSeconds, int maxHistoryMinutes, double maxHeatOpacity, double minVisibleOpacity, int heatmapMaxReference, bool filterSmallLiquidity, int minLiquidityThreshold, bool showActiveLiquidityExtension, bool showLastPriceLine, bool showHeatScale, bool showBestBidAskLines, bool showVolumeDots, int minDotVolume, int dotVolumeReference, int dotMaxRadius, double dotOpacity, bool showOrderBookPanel, int orderBookPanelWidth, bool showAbsorptionMarkers, int absorptionMinContracts, int absorptionWindowTicks, double icebergRatioThreshold, bool showPulledWallMarkers, int pulledWallMinContracts, int pulledWallMaxExecutedPct, double brokenMarkerFade, float absorptionMaxWidth, double absorptionMinOpacity, int refreshIntervalMs, int cleanupIntervalSeconds, int staleLevelMinutes, bool enableTelemetryLog)
		{
			if (cacheLiquidityHeatmap != null)
				for (int idx = 0; idx < cacheLiquidityHeatmap.Length; idx++)
					if (cacheLiquidityHeatmap[idx].RTHStartHHMM == rTHStartHHMM && cacheLiquidityHeatmap[idx].BookmapMode == bookmapMode && cacheLiquidityHeatmap[idx].SnapshotIntervalSeconds == snapshotIntervalSeconds && cacheLiquidityHeatmap[idx].MaxHistoryMinutes == maxHistoryMinutes && cacheLiquidityHeatmap[idx].MaxHeatOpacity == maxHeatOpacity && cacheLiquidityHeatmap[idx].MinVisibleOpacity == minVisibleOpacity && cacheLiquidityHeatmap[idx].HeatmapMaxReference == heatmapMaxReference && cacheLiquidityHeatmap[idx].FilterSmallLiquidity == filterSmallLiquidity && cacheLiquidityHeatmap[idx].MinLiquidityThreshold == minLiquidityThreshold && cacheLiquidityHeatmap[idx].ShowActiveLiquidityExtension == showActiveLiquidityExtension && cacheLiquidityHeatmap[idx].ShowLastPriceLine == showLastPriceLine && cacheLiquidityHeatmap[idx].ShowHeatScale == showHeatScale && cacheLiquidityHeatmap[idx].ShowBestBidAskLines == showBestBidAskLines && cacheLiquidityHeatmap[idx].ShowVolumeDots == showVolumeDots && cacheLiquidityHeatmap[idx].MinDotVolume == minDotVolume && cacheLiquidityHeatmap[idx].DotVolumeReference == dotVolumeReference && cacheLiquidityHeatmap[idx].DotMaxRadius == dotMaxRadius && cacheLiquidityHeatmap[idx].DotOpacity == dotOpacity && cacheLiquidityHeatmap[idx].ShowOrderBookPanel == showOrderBookPanel && cacheLiquidityHeatmap[idx].OrderBookPanelWidth == orderBookPanelWidth && cacheLiquidityHeatmap[idx].ShowAbsorptionMarkers == showAbsorptionMarkers && cacheLiquidityHeatmap[idx].AbsorptionMinContracts == absorptionMinContracts && cacheLiquidityHeatmap[idx].AbsorptionWindowTicks == absorptionWindowTicks && cacheLiquidityHeatmap[idx].IcebergRatioThreshold == icebergRatioThreshold && cacheLiquidityHeatmap[idx].ShowPulledWallMarkers == showPulledWallMarkers && cacheLiquidityHeatmap[idx].PulledWallMinContracts == pulledWallMinContracts && cacheLiquidityHeatmap[idx].PulledWallMaxExecutedPct == pulledWallMaxExecutedPct && cacheLiquidityHeatmap[idx].BrokenMarkerFade == brokenMarkerFade && cacheLiquidityHeatmap[idx].AbsorptionMaxWidth == absorptionMaxWidth && cacheLiquidityHeatmap[idx].AbsorptionMinOpacity == absorptionMinOpacity && cacheLiquidityHeatmap[idx].RefreshIntervalMs == refreshIntervalMs && cacheLiquidityHeatmap[idx].CleanupIntervalSeconds == cleanupIntervalSeconds && cacheLiquidityHeatmap[idx].StaleLevelMinutes == staleLevelMinutes && cacheLiquidityHeatmap[idx].EnableTelemetryLog == enableTelemetryLog && cacheLiquidityHeatmap[idx].EqualsInput(input))
						return cacheLiquidityHeatmap[idx];
			return CacheIndicator<LiquidityHeatmap>(new LiquidityHeatmap(){ RTHStartHHMM = rTHStartHHMM, BookmapMode = bookmapMode, SnapshotIntervalSeconds = snapshotIntervalSeconds, MaxHistoryMinutes = maxHistoryMinutes, MaxHeatOpacity = maxHeatOpacity, MinVisibleOpacity = minVisibleOpacity, HeatmapMaxReference = heatmapMaxReference, FilterSmallLiquidity = filterSmallLiquidity, MinLiquidityThreshold = minLiquidityThreshold, ShowActiveLiquidityExtension = showActiveLiquidityExtension, ShowLastPriceLine = showLastPriceLine, ShowHeatScale = showHeatScale, ShowBestBidAskLines = showBestBidAskLines, ShowVolumeDots = showVolumeDots, MinDotVolume = minDotVolume, DotVolumeReference = dotVolumeReference, DotMaxRadius = dotMaxRadius, DotOpacity = dotOpacity, ShowOrderBookPanel = showOrderBookPanel, OrderBookPanelWidth = orderBookPanelWidth, ShowAbsorptionMarkers = showAbsorptionMarkers, AbsorptionMinContracts = absorptionMinContracts, AbsorptionWindowTicks = absorptionWindowTicks, IcebergRatioThreshold = icebergRatioThreshold, ShowPulledWallMarkers = showPulledWallMarkers, PulledWallMinContracts = pulledWallMinContracts, PulledWallMaxExecutedPct = pulledWallMaxExecutedPct, BrokenMarkerFade = brokenMarkerFade, AbsorptionMaxWidth = absorptionMaxWidth, AbsorptionMinOpacity = absorptionMinOpacity, RefreshIntervalMs = refreshIntervalMs, CleanupIntervalSeconds = cleanupIntervalSeconds, StaleLevelMinutes = staleLevelMinutes, EnableTelemetryLog = enableTelemetryLog }, input, ref cacheLiquidityHeatmap);
		}

		public MonthlyMGI MonthlyMGI(ISeries<double> input, TimeSpan sessionStartTime, int monthsOfHistory, bool showPreviousMonths, bool showPriorMonthLevels, bool showPriorMonthProfile, double valueAreaPercent, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			if (cacheMonthlyMGI != null)
				for (int idx = 0; idx < cacheMonthlyMGI.Length; idx++)
					if (cacheMonthlyMGI[idx].SessionStartTime == sessionStartTime && cacheMonthlyMGI[idx].MonthsOfHistory == monthsOfHistory && cacheMonthlyMGI[idx].ShowPreviousMonths == showPreviousMonths && cacheMonthlyMGI[idx].ShowPriorMonthLevels == showPriorMonthLevels && cacheMonthlyMGI[idx].ShowPriorMonthProfile == showPriorMonthProfile && cacheMonthlyMGI[idx].ValueAreaPercent == valueAreaPercent && cacheMonthlyMGI[idx].ShowLabels == showLabels && cacheMonthlyMGI[idx].ShowValues == showValues && cacheMonthlyMGI[idx].LabelDistance == labelDistance && cacheMonthlyMGI[idx].LineWidth == lineWidth && cacheMonthlyMGI[idx].EqualsInput(input))
						return cacheMonthlyMGI[idx];
			return CacheIndicator<MonthlyMGI>(new MonthlyMGI(){ SessionStartTime = sessionStartTime, MonthsOfHistory = monthsOfHistory, ShowPreviousMonths = showPreviousMonths, ShowPriorMonthLevels = showPriorMonthLevels, ShowPriorMonthProfile = showPriorMonthProfile, ValueAreaPercent = valueAreaPercent, ShowLabels = showLabels, ShowValues = showValues, LabelDistance = labelDistance, LineWidth = lineWidth }, input, ref cacheMonthlyMGI);
		}

		public MonthlyVWAP MonthlyVWAP(ISeries<double> input, TimeSpan sessionStartTime)
		{
			if (cacheMonthlyVWAP != null)
				for (int idx = 0; idx < cacheMonthlyVWAP.Length; idx++)
					if (cacheMonthlyVWAP[idx].SessionStartTime == sessionStartTime && cacheMonthlyVWAP[idx].EqualsInput(input))
						return cacheMonthlyVWAP[idx];
			return CacheIndicator<MonthlyVWAP>(new MonthlyVWAP(){ SessionStartTime = sessionStartTime }, input, ref cacheMonthlyVWAP);
		}

		public QuarterlyMGI QuarterlyMGI(ISeries<double> input, TimeSpan sessionStartTime, int quartersOfHistory, bool showPreviousQuarters, bool showPriorQuarterLevels, bool showPriorQuarterProfile, double valueAreaPercent, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			if (cacheQuarterlyMGI != null)
				for (int idx = 0; idx < cacheQuarterlyMGI.Length; idx++)
					if (cacheQuarterlyMGI[idx].SessionStartTime == sessionStartTime && cacheQuarterlyMGI[idx].QuartersOfHistory == quartersOfHistory && cacheQuarterlyMGI[idx].ShowPreviousQuarters == showPreviousQuarters && cacheQuarterlyMGI[idx].ShowPriorQuarterLevels == showPriorQuarterLevels && cacheQuarterlyMGI[idx].ShowPriorQuarterProfile == showPriorQuarterProfile && cacheQuarterlyMGI[idx].ValueAreaPercent == valueAreaPercent && cacheQuarterlyMGI[idx].ShowLabels == showLabels && cacheQuarterlyMGI[idx].ShowValues == showValues && cacheQuarterlyMGI[idx].LabelDistance == labelDistance && cacheQuarterlyMGI[idx].LineWidth == lineWidth && cacheQuarterlyMGI[idx].EqualsInput(input))
						return cacheQuarterlyMGI[idx];
			return CacheIndicator<QuarterlyMGI>(new QuarterlyMGI(){ SessionStartTime = sessionStartTime, QuartersOfHistory = quartersOfHistory, ShowPreviousQuarters = showPreviousQuarters, ShowPriorQuarterLevels = showPriorQuarterLevels, ShowPriorQuarterProfile = showPriorQuarterProfile, ValueAreaPercent = valueAreaPercent, ShowLabels = showLabels, ShowValues = showValues, LabelDistance = labelDistance, LineWidth = lineWidth }, input, ref cacheQuarterlyMGI);
		}

		public QuarterlyVWAP QuarterlyVWAP(ISeries<double> input, TimeSpan sessionStartTime)
		{
			if (cacheQuarterlyVWAP != null)
				for (int idx = 0; idx < cacheQuarterlyVWAP.Length; idx++)
					if (cacheQuarterlyVWAP[idx].SessionStartTime == sessionStartTime && cacheQuarterlyVWAP[idx].EqualsInput(input))
						return cacheQuarterlyVWAP[idx];
			return CacheIndicator<QuarterlyVWAP>(new QuarterlyVWAP(){ SessionStartTime = sessionStartTime }, input, ref cacheQuarterlyVWAP);
		}

		public SessionTpoVolumeProfile SessionTpoVolumeProfile(ISeries<double> input, int ticksPerRow, int bracketMinutes, double valueAreaPercent, int minTailRows)
		{
			if (cacheSessionTpoVolumeProfile != null)
				for (int idx = 0; idx < cacheSessionTpoVolumeProfile.Length; idx++)
					if (cacheSessionTpoVolumeProfile[idx].TicksPerRow == ticksPerRow && cacheSessionTpoVolumeProfile[idx].BracketMinutes == bracketMinutes && cacheSessionTpoVolumeProfile[idx].ValueAreaPercent == valueAreaPercent && cacheSessionTpoVolumeProfile[idx].MinTailRows == minTailRows && cacheSessionTpoVolumeProfile[idx].EqualsInput(input))
						return cacheSessionTpoVolumeProfile[idx];
			return CacheIndicator<SessionTpoVolumeProfile>(new SessionTpoVolumeProfile(){ TicksPerRow = ticksPerRow, BracketMinutes = bracketMinutes, ValueAreaPercent = valueAreaPercent, MinTailRows = minTailRows }, input, ref cacheSessionTpoVolumeProfile);
		}

		public WeeklyMGI WeeklyMGI(ISeries<double> input, TimeSpan weeklyOpenTime, TimeSpan weeklyCloseTime, int weeksOfHistory, bool showPreviousWeeks, bool showPriorWeekLevels, bool showPriorWeekProfile, double valueAreaPercent, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			if (cacheWeeklyMGI != null)
				for (int idx = 0; idx < cacheWeeklyMGI.Length; idx++)
					if (cacheWeeklyMGI[idx].WeeklyOpenTime == weeklyOpenTime && cacheWeeklyMGI[idx].WeeklyCloseTime == weeklyCloseTime && cacheWeeklyMGI[idx].WeeksOfHistory == weeksOfHistory && cacheWeeklyMGI[idx].ShowPreviousWeeks == showPreviousWeeks && cacheWeeklyMGI[idx].ShowPriorWeekLevels == showPriorWeekLevels && cacheWeeklyMGI[idx].ShowPriorWeekProfile == showPriorWeekProfile && cacheWeeklyMGI[idx].ValueAreaPercent == valueAreaPercent && cacheWeeklyMGI[idx].ShowLabels == showLabels && cacheWeeklyMGI[idx].ShowValues == showValues && cacheWeeklyMGI[idx].LabelDistance == labelDistance && cacheWeeklyMGI[idx].LineWidth == lineWidth && cacheWeeklyMGI[idx].EqualsInput(input))
						return cacheWeeklyMGI[idx];
			return CacheIndicator<WeeklyMGI>(new WeeklyMGI(){ WeeklyOpenTime = weeklyOpenTime, WeeklyCloseTime = weeklyCloseTime, WeeksOfHistory = weeksOfHistory, ShowPreviousWeeks = showPreviousWeeks, ShowPriorWeekLevels = showPriorWeekLevels, ShowPriorWeekProfile = showPriorWeekProfile, ValueAreaPercent = valueAreaPercent, ShowLabels = showLabels, ShowValues = showValues, LabelDistance = labelDistance, LineWidth = lineWidth }, input, ref cacheWeeklyMGI);
		}

		public WeeklyVWAP WeeklyVWAP(ISeries<double> input, TimeSpan weeklyOpenTime, TimeSpan weeklyCloseTime)
		{
			if (cacheWeeklyVWAP != null)
				for (int idx = 0; idx < cacheWeeklyVWAP.Length; idx++)
					if (cacheWeeklyVWAP[idx].WeeklyOpenTime == weeklyOpenTime && cacheWeeklyVWAP[idx].WeeklyCloseTime == weeklyCloseTime && cacheWeeklyVWAP[idx].EqualsInput(input))
						return cacheWeeklyVWAP[idx];
			return CacheIndicator<WeeklyVWAP>(new WeeklyVWAP(){ WeeklyOpenTime = weeklyOpenTime, WeeklyCloseTime = weeklyCloseTime }, input, ref cacheWeeklyVWAP);
		}

		public YearlyMGI YearlyMGI(ISeries<double> input, TimeSpan sessionStartTime, int yearsOfHistory, bool showPreviousYears, bool showPriorYearLevels, bool showPriorYearProfile, double valueAreaPercent, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			if (cacheYearlyMGI != null)
				for (int idx = 0; idx < cacheYearlyMGI.Length; idx++)
					if (cacheYearlyMGI[idx].SessionStartTime == sessionStartTime && cacheYearlyMGI[idx].YearsOfHistory == yearsOfHistory && cacheYearlyMGI[idx].ShowPreviousYears == showPreviousYears && cacheYearlyMGI[idx].ShowPriorYearLevels == showPriorYearLevels && cacheYearlyMGI[idx].ShowPriorYearProfile == showPriorYearProfile && cacheYearlyMGI[idx].ValueAreaPercent == valueAreaPercent && cacheYearlyMGI[idx].ShowLabels == showLabels && cacheYearlyMGI[idx].ShowValues == showValues && cacheYearlyMGI[idx].LabelDistance == labelDistance && cacheYearlyMGI[idx].LineWidth == lineWidth && cacheYearlyMGI[idx].EqualsInput(input))
						return cacheYearlyMGI[idx];
			return CacheIndicator<YearlyMGI>(new YearlyMGI(){ SessionStartTime = sessionStartTime, YearsOfHistory = yearsOfHistory, ShowPreviousYears = showPreviousYears, ShowPriorYearLevels = showPriorYearLevels, ShowPriorYearProfile = showPriorYearProfile, ValueAreaPercent = valueAreaPercent, ShowLabels = showLabels, ShowValues = showValues, LabelDistance = labelDistance, LineWidth = lineWidth }, input, ref cacheYearlyMGI);
		}

		public YearlyVWAP YearlyVWAP(ISeries<double> input, TimeSpan sessionStartTime)
		{
			if (cacheYearlyVWAP != null)
				for (int idx = 0; idx < cacheYearlyVWAP.Length; idx++)
					if (cacheYearlyVWAP[idx].SessionStartTime == sessionStartTime && cacheYearlyVWAP[idx].EqualsInput(input))
						return cacheYearlyVWAP[idx];
			return CacheIndicator<YearlyVWAP>(new YearlyVWAP(){ SessionStartTime = sessionStartTime }, input, ref cacheYearlyVWAP);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.MATE.Profiles.AnchoredVolumeProfile AnchoredVolumeProfile()
		{
			return indicator.AnchoredVolumeProfile(Input);
		}

		public Indicators.MATE.Tools.AuctionContext AuctionContext(string rthTemplateName, bool manualTimesInEt, string rthStartText, string rthEndText, int ibMinutes, bool onStartsAtGlobexReopen, string globexOpenText, int lookback, bool useMedian, int minOnMinutes, int minRthMinutes, bool enableRotations, AcxRotationSequence rotationSequence, int rotationReversalTicks, bool showRotationDetail, bool enableDelta, bool enableCsvLog, bool enableAuditLog, bool showDataQuality, int panelFontSize, AcxPanelSide panelSide, bool showOvernightRange, bool showInitialBalanceRange, bool showRthRange, bool showEthRange, bool showRthVolume, bool showRelativeVolume, bool showOvernightVolume, bool showWeeklyRange, bool showWeeklyVolume, int weeksLookback, bool showOvernightInventory, bool showOvernightDelta, bool showIbExtensions, int panelRightMargin, int panelTopMargin)
		{
			return indicator.AuctionContext(Input, rthTemplateName, manualTimesInEt, rthStartText, rthEndText, ibMinutes, onStartsAtGlobexReopen, globexOpenText, lookback, useMedian, minOnMinutes, minRthMinutes, enableRotations, rotationSequence, rotationReversalTicks, showRotationDetail, enableDelta, enableCsvLog, enableAuditLog, showDataQuality, panelFontSize, panelSide, showOvernightRange, showInitialBalanceRange, showRthRange, showEthRange, showRthVolume, showRelativeVolume, showOvernightVolume, showWeeklyRange, showWeeklyVolume, weeksLookback, showOvernightInventory, showOvernightDelta, showIbExtensions, panelRightMargin, panelTopMargin);
		}

		public Indicators.MATE.OrderFlow.BigTradesInstitutional BigTradesInstitutional()
		{
			return indicator.BigTradesInstitutional(Input);
		}

		public Indicators.MATE.MGI.DailyMGI DailyMGI(TimeSpan rTHStartTime, TimeSpan rTHEndTime, TimeSpan overnightStartTime, TimeSpan overnightEndTime, TimeSpan eTHStartTime, TimeSpan eTHEndTime, int initialBalanceMinutes, int daysOfHistory, bool showPreviousDays, bool showOvernightRange, bool showInitialBalance, bool showIBExtensions, bool showPriorDayRTH, bool showPriorDayETH, bool showPriorDayProfile, bool showPriorETHProfile, bool showONProfile, double valueAreaPercent, bool showHalfGap, double iBExtensionMultiplier0, double iBExtensionMultiplier1, double iBExtensionMultiplier2, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			return indicator.DailyMGI(Input, rTHStartTime, rTHEndTime, overnightStartTime, overnightEndTime, eTHStartTime, eTHEndTime, initialBalanceMinutes, daysOfHistory, showPreviousDays, showOvernightRange, showInitialBalance, showIBExtensions, showPriorDayRTH, showPriorDayETH, showPriorDayProfile, showPriorETHProfile, showONProfile, valueAreaPercent, showHalfGap, iBExtensionMultiplier0, iBExtensionMultiplier1, iBExtensionMultiplier2, showLabels, showValues, labelDistance, lineWidth);
		}

		public Indicators.MATE.VWAP.DailyVWAP DailyVWAP(TimeSpan rTHStartTime, TimeSpan rTHEndTime, TimeSpan eTHStartTime, TimeSpan eTHEndTime)
		{
			return indicator.DailyVWAP(Input, rTHStartTime, rTHEndTime, eTHStartTime, eTHEndTime);
		}

		public Indicators.MATE.OrderFlow.DeltaProfile DeltaProfile()
		{
			return indicator.DeltaProfile(Input);
		}

		public Indicators.MATE.OrderFlow.DeltaSuite DeltaSuite(double bigTradeThreshold)
		{
			return indicator.DeltaSuite(Input, bigTradeThreshold);
		}

		public Indicators.MATE.Profiles.FixedRangeVolumeProfile FixedRangeVolumeProfile(int ticksPerRow)
		{
			return indicator.FixedRangeVolumeProfile(Input, ticksPerRow);
		}

		public Indicators.MATE.OrderFlow.FootprintOrderFlow FootprintOrderFlow()
		{
			return indicator.FootprintOrderFlow(Input);
		}

		public Indicators.MATE.Tools.LagSentinel LagSentinel(LagSentinelLocation location, int hOffset, int vOffset, double lagThresholdSeconds, double staleQuoteSeconds, double orderAckThresholdSeconds, double uiLagThresholdSeconds, int fontSize, bool alertOnDegraded, string alertSound)
		{
			return indicator.LagSentinel(Input, location, hOffset, vOffset, lagThresholdSeconds, staleQuoteSeconds, orderAckThresholdSeconds, uiLagThresholdSeconds, fontSize, alertOnDegraded, alertSound);
		}

		public Indicators.MATE.OrderFlow.LiquidityHeatmap LiquidityHeatmap(int rTHStartHHMM, bool bookmapMode, int snapshotIntervalSeconds, int maxHistoryMinutes, double maxHeatOpacity, double minVisibleOpacity, int heatmapMaxReference, bool filterSmallLiquidity, int minLiquidityThreshold, bool showActiveLiquidityExtension, bool showLastPriceLine, bool showHeatScale, bool showBestBidAskLines, bool showVolumeDots, int minDotVolume, int dotVolumeReference, int dotMaxRadius, double dotOpacity, bool showOrderBookPanel, int orderBookPanelWidth, bool showAbsorptionMarkers, int absorptionMinContracts, int absorptionWindowTicks, double icebergRatioThreshold, bool showPulledWallMarkers, int pulledWallMinContracts, int pulledWallMaxExecutedPct, double brokenMarkerFade, float absorptionMaxWidth, double absorptionMinOpacity, int refreshIntervalMs, int cleanupIntervalSeconds, int staleLevelMinutes, bool enableTelemetryLog)
		{
			return indicator.LiquidityHeatmap(Input, rTHStartHHMM, bookmapMode, snapshotIntervalSeconds, maxHistoryMinutes, maxHeatOpacity, minVisibleOpacity, heatmapMaxReference, filterSmallLiquidity, minLiquidityThreshold, showActiveLiquidityExtension, showLastPriceLine, showHeatScale, showBestBidAskLines, showVolumeDots, minDotVolume, dotVolumeReference, dotMaxRadius, dotOpacity, showOrderBookPanel, orderBookPanelWidth, showAbsorptionMarkers, absorptionMinContracts, absorptionWindowTicks, icebergRatioThreshold, showPulledWallMarkers, pulledWallMinContracts, pulledWallMaxExecutedPct, brokenMarkerFade, absorptionMaxWidth, absorptionMinOpacity, refreshIntervalMs, cleanupIntervalSeconds, staleLevelMinutes, enableTelemetryLog);
		}

		public Indicators.MATE.MGI.MonthlyMGI MonthlyMGI(TimeSpan sessionStartTime, int monthsOfHistory, bool showPreviousMonths, bool showPriorMonthLevels, bool showPriorMonthProfile, double valueAreaPercent, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			return indicator.MonthlyMGI(Input, sessionStartTime, monthsOfHistory, showPreviousMonths, showPriorMonthLevels, showPriorMonthProfile, valueAreaPercent, showLabels, showValues, labelDistance, lineWidth);
		}

		public Indicators.MATE.VWAP.MonthlyVWAP MonthlyVWAP(TimeSpan sessionStartTime)
		{
			return indicator.MonthlyVWAP(Input, sessionStartTime);
		}

		public Indicators.MATE.MGI.QuarterlyMGI QuarterlyMGI(TimeSpan sessionStartTime, int quartersOfHistory, bool showPreviousQuarters, bool showPriorQuarterLevels, bool showPriorQuarterProfile, double valueAreaPercent, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			return indicator.QuarterlyMGI(Input, sessionStartTime, quartersOfHistory, showPreviousQuarters, showPriorQuarterLevels, showPriorQuarterProfile, valueAreaPercent, showLabels, showValues, labelDistance, lineWidth);
		}

		public Indicators.MATE.VWAP.QuarterlyVWAP QuarterlyVWAP(TimeSpan sessionStartTime)
		{
			return indicator.QuarterlyVWAP(Input, sessionStartTime);
		}

		public Indicators.MATE.Profiles.SessionTpoVolumeProfile SessionTpoVolumeProfile(int ticksPerRow, int bracketMinutes, double valueAreaPercent, int minTailRows)
		{
			return indicator.SessionTpoVolumeProfile(Input, ticksPerRow, bracketMinutes, valueAreaPercent, minTailRows);
		}

		public Indicators.MATE.MGI.WeeklyMGI WeeklyMGI(TimeSpan weeklyOpenTime, TimeSpan weeklyCloseTime, int weeksOfHistory, bool showPreviousWeeks, bool showPriorWeekLevels, bool showPriorWeekProfile, double valueAreaPercent, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			return indicator.WeeklyMGI(Input, weeklyOpenTime, weeklyCloseTime, weeksOfHistory, showPreviousWeeks, showPriorWeekLevels, showPriorWeekProfile, valueAreaPercent, showLabels, showValues, labelDistance, lineWidth);
		}

		public Indicators.MATE.VWAP.WeeklyVWAP WeeklyVWAP(TimeSpan weeklyOpenTime, TimeSpan weeklyCloseTime)
		{
			return indicator.WeeklyVWAP(Input, weeklyOpenTime, weeklyCloseTime);
		}

		public Indicators.MATE.MGI.YearlyMGI YearlyMGI(TimeSpan sessionStartTime, int yearsOfHistory, bool showPreviousYears, bool showPriorYearLevels, bool showPriorYearProfile, double valueAreaPercent, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			return indicator.YearlyMGI(Input, sessionStartTime, yearsOfHistory, showPreviousYears, showPriorYearLevels, showPriorYearProfile, valueAreaPercent, showLabels, showValues, labelDistance, lineWidth);
		}

		public Indicators.MATE.VWAP.YearlyVWAP YearlyVWAP(TimeSpan sessionStartTime)
		{
			return indicator.YearlyVWAP(Input, sessionStartTime);
		}


		
		public Indicators.MATE.Profiles.AnchoredVolumeProfile AnchoredVolumeProfile(ISeries<double> input )
		{
			return indicator.AnchoredVolumeProfile(input);
		}

		public Indicators.MATE.Tools.AuctionContext AuctionContext(ISeries<double> input , string rthTemplateName, bool manualTimesInEt, string rthStartText, string rthEndText, int ibMinutes, bool onStartsAtGlobexReopen, string globexOpenText, int lookback, bool useMedian, int minOnMinutes, int minRthMinutes, bool enableRotations, AcxRotationSequence rotationSequence, int rotationReversalTicks, bool showRotationDetail, bool enableDelta, bool enableCsvLog, bool enableAuditLog, bool showDataQuality, int panelFontSize, AcxPanelSide panelSide, bool showOvernightRange, bool showInitialBalanceRange, bool showRthRange, bool showEthRange, bool showRthVolume, bool showRelativeVolume, bool showOvernightVolume, bool showWeeklyRange, bool showWeeklyVolume, int weeksLookback, bool showOvernightInventory, bool showOvernightDelta, bool showIbExtensions, int panelRightMargin, int panelTopMargin)
		{
			return indicator.AuctionContext(input, rthTemplateName, manualTimesInEt, rthStartText, rthEndText, ibMinutes, onStartsAtGlobexReopen, globexOpenText, lookback, useMedian, minOnMinutes, minRthMinutes, enableRotations, rotationSequence, rotationReversalTicks, showRotationDetail, enableDelta, enableCsvLog, enableAuditLog, showDataQuality, panelFontSize, panelSide, showOvernightRange, showInitialBalanceRange, showRthRange, showEthRange, showRthVolume, showRelativeVolume, showOvernightVolume, showWeeklyRange, showWeeklyVolume, weeksLookback, showOvernightInventory, showOvernightDelta, showIbExtensions, panelRightMargin, panelTopMargin);
		}

		public Indicators.MATE.OrderFlow.BigTradesInstitutional BigTradesInstitutional(ISeries<double> input )
		{
			return indicator.BigTradesInstitutional(input);
		}

		public Indicators.MATE.MGI.DailyMGI DailyMGI(ISeries<double> input , TimeSpan rTHStartTime, TimeSpan rTHEndTime, TimeSpan overnightStartTime, TimeSpan overnightEndTime, TimeSpan eTHStartTime, TimeSpan eTHEndTime, int initialBalanceMinutes, int daysOfHistory, bool showPreviousDays, bool showOvernightRange, bool showInitialBalance, bool showIBExtensions, bool showPriorDayRTH, bool showPriorDayETH, bool showPriorDayProfile, bool showPriorETHProfile, bool showONProfile, double valueAreaPercent, bool showHalfGap, double iBExtensionMultiplier0, double iBExtensionMultiplier1, double iBExtensionMultiplier2, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			return indicator.DailyMGI(input, rTHStartTime, rTHEndTime, overnightStartTime, overnightEndTime, eTHStartTime, eTHEndTime, initialBalanceMinutes, daysOfHistory, showPreviousDays, showOvernightRange, showInitialBalance, showIBExtensions, showPriorDayRTH, showPriorDayETH, showPriorDayProfile, showPriorETHProfile, showONProfile, valueAreaPercent, showHalfGap, iBExtensionMultiplier0, iBExtensionMultiplier1, iBExtensionMultiplier2, showLabels, showValues, labelDistance, lineWidth);
		}

		public Indicators.MATE.VWAP.DailyVWAP DailyVWAP(ISeries<double> input , TimeSpan rTHStartTime, TimeSpan rTHEndTime, TimeSpan eTHStartTime, TimeSpan eTHEndTime)
		{
			return indicator.DailyVWAP(input, rTHStartTime, rTHEndTime, eTHStartTime, eTHEndTime);
		}

		public Indicators.MATE.OrderFlow.DeltaProfile DeltaProfile(ISeries<double> input )
		{
			return indicator.DeltaProfile(input);
		}

		public Indicators.MATE.OrderFlow.DeltaSuite DeltaSuite(ISeries<double> input , double bigTradeThreshold)
		{
			return indicator.DeltaSuite(input, bigTradeThreshold);
		}

		public Indicators.MATE.Profiles.FixedRangeVolumeProfile FixedRangeVolumeProfile(ISeries<double> input , int ticksPerRow)
		{
			return indicator.FixedRangeVolumeProfile(input, ticksPerRow);
		}

		public Indicators.MATE.OrderFlow.FootprintOrderFlow FootprintOrderFlow(ISeries<double> input )
		{
			return indicator.FootprintOrderFlow(input);
		}

		public Indicators.MATE.Tools.LagSentinel LagSentinel(ISeries<double> input , LagSentinelLocation location, int hOffset, int vOffset, double lagThresholdSeconds, double staleQuoteSeconds, double orderAckThresholdSeconds, double uiLagThresholdSeconds, int fontSize, bool alertOnDegraded, string alertSound)
		{
			return indicator.LagSentinel(input, location, hOffset, vOffset, lagThresholdSeconds, staleQuoteSeconds, orderAckThresholdSeconds, uiLagThresholdSeconds, fontSize, alertOnDegraded, alertSound);
		}

		public Indicators.MATE.OrderFlow.LiquidityHeatmap LiquidityHeatmap(ISeries<double> input , int rTHStartHHMM, bool bookmapMode, int snapshotIntervalSeconds, int maxHistoryMinutes, double maxHeatOpacity, double minVisibleOpacity, int heatmapMaxReference, bool filterSmallLiquidity, int minLiquidityThreshold, bool showActiveLiquidityExtension, bool showLastPriceLine, bool showHeatScale, bool showBestBidAskLines, bool showVolumeDots, int minDotVolume, int dotVolumeReference, int dotMaxRadius, double dotOpacity, bool showOrderBookPanel, int orderBookPanelWidth, bool showAbsorptionMarkers, int absorptionMinContracts, int absorptionWindowTicks, double icebergRatioThreshold, bool showPulledWallMarkers, int pulledWallMinContracts, int pulledWallMaxExecutedPct, double brokenMarkerFade, float absorptionMaxWidth, double absorptionMinOpacity, int refreshIntervalMs, int cleanupIntervalSeconds, int staleLevelMinutes, bool enableTelemetryLog)
		{
			return indicator.LiquidityHeatmap(input, rTHStartHHMM, bookmapMode, snapshotIntervalSeconds, maxHistoryMinutes, maxHeatOpacity, minVisibleOpacity, heatmapMaxReference, filterSmallLiquidity, minLiquidityThreshold, showActiveLiquidityExtension, showLastPriceLine, showHeatScale, showBestBidAskLines, showVolumeDots, minDotVolume, dotVolumeReference, dotMaxRadius, dotOpacity, showOrderBookPanel, orderBookPanelWidth, showAbsorptionMarkers, absorptionMinContracts, absorptionWindowTicks, icebergRatioThreshold, showPulledWallMarkers, pulledWallMinContracts, pulledWallMaxExecutedPct, brokenMarkerFade, absorptionMaxWidth, absorptionMinOpacity, refreshIntervalMs, cleanupIntervalSeconds, staleLevelMinutes, enableTelemetryLog);
		}

		public Indicators.MATE.MGI.MonthlyMGI MonthlyMGI(ISeries<double> input , TimeSpan sessionStartTime, int monthsOfHistory, bool showPreviousMonths, bool showPriorMonthLevels, bool showPriorMonthProfile, double valueAreaPercent, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			return indicator.MonthlyMGI(input, sessionStartTime, monthsOfHistory, showPreviousMonths, showPriorMonthLevels, showPriorMonthProfile, valueAreaPercent, showLabels, showValues, labelDistance, lineWidth);
		}

		public Indicators.MATE.VWAP.MonthlyVWAP MonthlyVWAP(ISeries<double> input , TimeSpan sessionStartTime)
		{
			return indicator.MonthlyVWAP(input, sessionStartTime);
		}

		public Indicators.MATE.MGI.QuarterlyMGI QuarterlyMGI(ISeries<double> input , TimeSpan sessionStartTime, int quartersOfHistory, bool showPreviousQuarters, bool showPriorQuarterLevels, bool showPriorQuarterProfile, double valueAreaPercent, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			return indicator.QuarterlyMGI(input, sessionStartTime, quartersOfHistory, showPreviousQuarters, showPriorQuarterLevels, showPriorQuarterProfile, valueAreaPercent, showLabels, showValues, labelDistance, lineWidth);
		}

		public Indicators.MATE.VWAP.QuarterlyVWAP QuarterlyVWAP(ISeries<double> input , TimeSpan sessionStartTime)
		{
			return indicator.QuarterlyVWAP(input, sessionStartTime);
		}

		public Indicators.MATE.Profiles.SessionTpoVolumeProfile SessionTpoVolumeProfile(ISeries<double> input , int ticksPerRow, int bracketMinutes, double valueAreaPercent, int minTailRows)
		{
			return indicator.SessionTpoVolumeProfile(input, ticksPerRow, bracketMinutes, valueAreaPercent, minTailRows);
		}

		public Indicators.MATE.MGI.WeeklyMGI WeeklyMGI(ISeries<double> input , TimeSpan weeklyOpenTime, TimeSpan weeklyCloseTime, int weeksOfHistory, bool showPreviousWeeks, bool showPriorWeekLevels, bool showPriorWeekProfile, double valueAreaPercent, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			return indicator.WeeklyMGI(input, weeklyOpenTime, weeklyCloseTime, weeksOfHistory, showPreviousWeeks, showPriorWeekLevels, showPriorWeekProfile, valueAreaPercent, showLabels, showValues, labelDistance, lineWidth);
		}

		public Indicators.MATE.VWAP.WeeklyVWAP WeeklyVWAP(ISeries<double> input , TimeSpan weeklyOpenTime, TimeSpan weeklyCloseTime)
		{
			return indicator.WeeklyVWAP(input, weeklyOpenTime, weeklyCloseTime);
		}

		public Indicators.MATE.MGI.YearlyMGI YearlyMGI(ISeries<double> input , TimeSpan sessionStartTime, int yearsOfHistory, bool showPreviousYears, bool showPriorYearLevels, bool showPriorYearProfile, double valueAreaPercent, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			return indicator.YearlyMGI(input, sessionStartTime, yearsOfHistory, showPreviousYears, showPriorYearLevels, showPriorYearProfile, valueAreaPercent, showLabels, showValues, labelDistance, lineWidth);
		}

		public Indicators.MATE.VWAP.YearlyVWAP YearlyVWAP(ISeries<double> input , TimeSpan sessionStartTime)
		{
			return indicator.YearlyVWAP(input, sessionStartTime);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.MATE.Profiles.AnchoredVolumeProfile AnchoredVolumeProfile()
		{
			return indicator.AnchoredVolumeProfile(Input);
		}

		public Indicators.MATE.Tools.AuctionContext AuctionContext(string rthTemplateName, bool manualTimesInEt, string rthStartText, string rthEndText, int ibMinutes, bool onStartsAtGlobexReopen, string globexOpenText, int lookback, bool useMedian, int minOnMinutes, int minRthMinutes, bool enableRotations, AcxRotationSequence rotationSequence, int rotationReversalTicks, bool showRotationDetail, bool enableDelta, bool enableCsvLog, bool enableAuditLog, bool showDataQuality, int panelFontSize, AcxPanelSide panelSide, bool showOvernightRange, bool showInitialBalanceRange, bool showRthRange, bool showEthRange, bool showRthVolume, bool showRelativeVolume, bool showOvernightVolume, bool showWeeklyRange, bool showWeeklyVolume, int weeksLookback, bool showOvernightInventory, bool showOvernightDelta, bool showIbExtensions, int panelRightMargin, int panelTopMargin)
		{
			return indicator.AuctionContext(Input, rthTemplateName, manualTimesInEt, rthStartText, rthEndText, ibMinutes, onStartsAtGlobexReopen, globexOpenText, lookback, useMedian, minOnMinutes, minRthMinutes, enableRotations, rotationSequence, rotationReversalTicks, showRotationDetail, enableDelta, enableCsvLog, enableAuditLog, showDataQuality, panelFontSize, panelSide, showOvernightRange, showInitialBalanceRange, showRthRange, showEthRange, showRthVolume, showRelativeVolume, showOvernightVolume, showWeeklyRange, showWeeklyVolume, weeksLookback, showOvernightInventory, showOvernightDelta, showIbExtensions, panelRightMargin, panelTopMargin);
		}

		public Indicators.MATE.OrderFlow.BigTradesInstitutional BigTradesInstitutional()
		{
			return indicator.BigTradesInstitutional(Input);
		}

		public Indicators.MATE.MGI.DailyMGI DailyMGI(TimeSpan rTHStartTime, TimeSpan rTHEndTime, TimeSpan overnightStartTime, TimeSpan overnightEndTime, TimeSpan eTHStartTime, TimeSpan eTHEndTime, int initialBalanceMinutes, int daysOfHistory, bool showPreviousDays, bool showOvernightRange, bool showInitialBalance, bool showIBExtensions, bool showPriorDayRTH, bool showPriorDayETH, bool showPriorDayProfile, bool showPriorETHProfile, bool showONProfile, double valueAreaPercent, bool showHalfGap, double iBExtensionMultiplier0, double iBExtensionMultiplier1, double iBExtensionMultiplier2, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			return indicator.DailyMGI(Input, rTHStartTime, rTHEndTime, overnightStartTime, overnightEndTime, eTHStartTime, eTHEndTime, initialBalanceMinutes, daysOfHistory, showPreviousDays, showOvernightRange, showInitialBalance, showIBExtensions, showPriorDayRTH, showPriorDayETH, showPriorDayProfile, showPriorETHProfile, showONProfile, valueAreaPercent, showHalfGap, iBExtensionMultiplier0, iBExtensionMultiplier1, iBExtensionMultiplier2, showLabels, showValues, labelDistance, lineWidth);
		}

		public Indicators.MATE.VWAP.DailyVWAP DailyVWAP(TimeSpan rTHStartTime, TimeSpan rTHEndTime, TimeSpan eTHStartTime, TimeSpan eTHEndTime)
		{
			return indicator.DailyVWAP(Input, rTHStartTime, rTHEndTime, eTHStartTime, eTHEndTime);
		}

		public Indicators.MATE.OrderFlow.DeltaProfile DeltaProfile()
		{
			return indicator.DeltaProfile(Input);
		}

		public Indicators.MATE.OrderFlow.DeltaSuite DeltaSuite(double bigTradeThreshold)
		{
			return indicator.DeltaSuite(Input, bigTradeThreshold);
		}

		public Indicators.MATE.Profiles.FixedRangeVolumeProfile FixedRangeVolumeProfile(int ticksPerRow)
		{
			return indicator.FixedRangeVolumeProfile(Input, ticksPerRow);
		}

		public Indicators.MATE.OrderFlow.FootprintOrderFlow FootprintOrderFlow()
		{
			return indicator.FootprintOrderFlow(Input);
		}

		public Indicators.MATE.Tools.LagSentinel LagSentinel(LagSentinelLocation location, int hOffset, int vOffset, double lagThresholdSeconds, double staleQuoteSeconds, double orderAckThresholdSeconds, double uiLagThresholdSeconds, int fontSize, bool alertOnDegraded, string alertSound)
		{
			return indicator.LagSentinel(Input, location, hOffset, vOffset, lagThresholdSeconds, staleQuoteSeconds, orderAckThresholdSeconds, uiLagThresholdSeconds, fontSize, alertOnDegraded, alertSound);
		}

		public Indicators.MATE.OrderFlow.LiquidityHeatmap LiquidityHeatmap(int rTHStartHHMM, bool bookmapMode, int snapshotIntervalSeconds, int maxHistoryMinutes, double maxHeatOpacity, double minVisibleOpacity, int heatmapMaxReference, bool filterSmallLiquidity, int minLiquidityThreshold, bool showActiveLiquidityExtension, bool showLastPriceLine, bool showHeatScale, bool showBestBidAskLines, bool showVolumeDots, int minDotVolume, int dotVolumeReference, int dotMaxRadius, double dotOpacity, bool showOrderBookPanel, int orderBookPanelWidth, bool showAbsorptionMarkers, int absorptionMinContracts, int absorptionWindowTicks, double icebergRatioThreshold, bool showPulledWallMarkers, int pulledWallMinContracts, int pulledWallMaxExecutedPct, double brokenMarkerFade, float absorptionMaxWidth, double absorptionMinOpacity, int refreshIntervalMs, int cleanupIntervalSeconds, int staleLevelMinutes, bool enableTelemetryLog)
		{
			return indicator.LiquidityHeatmap(Input, rTHStartHHMM, bookmapMode, snapshotIntervalSeconds, maxHistoryMinutes, maxHeatOpacity, minVisibleOpacity, heatmapMaxReference, filterSmallLiquidity, minLiquidityThreshold, showActiveLiquidityExtension, showLastPriceLine, showHeatScale, showBestBidAskLines, showVolumeDots, minDotVolume, dotVolumeReference, dotMaxRadius, dotOpacity, showOrderBookPanel, orderBookPanelWidth, showAbsorptionMarkers, absorptionMinContracts, absorptionWindowTicks, icebergRatioThreshold, showPulledWallMarkers, pulledWallMinContracts, pulledWallMaxExecutedPct, brokenMarkerFade, absorptionMaxWidth, absorptionMinOpacity, refreshIntervalMs, cleanupIntervalSeconds, staleLevelMinutes, enableTelemetryLog);
		}

		public Indicators.MATE.MGI.MonthlyMGI MonthlyMGI(TimeSpan sessionStartTime, int monthsOfHistory, bool showPreviousMonths, bool showPriorMonthLevels, bool showPriorMonthProfile, double valueAreaPercent, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			return indicator.MonthlyMGI(Input, sessionStartTime, monthsOfHistory, showPreviousMonths, showPriorMonthLevels, showPriorMonthProfile, valueAreaPercent, showLabels, showValues, labelDistance, lineWidth);
		}

		public Indicators.MATE.VWAP.MonthlyVWAP MonthlyVWAP(TimeSpan sessionStartTime)
		{
			return indicator.MonthlyVWAP(Input, sessionStartTime);
		}

		public Indicators.MATE.MGI.QuarterlyMGI QuarterlyMGI(TimeSpan sessionStartTime, int quartersOfHistory, bool showPreviousQuarters, bool showPriorQuarterLevels, bool showPriorQuarterProfile, double valueAreaPercent, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			return indicator.QuarterlyMGI(Input, sessionStartTime, quartersOfHistory, showPreviousQuarters, showPriorQuarterLevels, showPriorQuarterProfile, valueAreaPercent, showLabels, showValues, labelDistance, lineWidth);
		}

		public Indicators.MATE.VWAP.QuarterlyVWAP QuarterlyVWAP(TimeSpan sessionStartTime)
		{
			return indicator.QuarterlyVWAP(Input, sessionStartTime);
		}

		public Indicators.MATE.Profiles.SessionTpoVolumeProfile SessionTpoVolumeProfile(int ticksPerRow, int bracketMinutes, double valueAreaPercent, int minTailRows)
		{
			return indicator.SessionTpoVolumeProfile(Input, ticksPerRow, bracketMinutes, valueAreaPercent, minTailRows);
		}

		public Indicators.MATE.MGI.WeeklyMGI WeeklyMGI(TimeSpan weeklyOpenTime, TimeSpan weeklyCloseTime, int weeksOfHistory, bool showPreviousWeeks, bool showPriorWeekLevels, bool showPriorWeekProfile, double valueAreaPercent, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			return indicator.WeeklyMGI(Input, weeklyOpenTime, weeklyCloseTime, weeksOfHistory, showPreviousWeeks, showPriorWeekLevels, showPriorWeekProfile, valueAreaPercent, showLabels, showValues, labelDistance, lineWidth);
		}

		public Indicators.MATE.VWAP.WeeklyVWAP WeeklyVWAP(TimeSpan weeklyOpenTime, TimeSpan weeklyCloseTime)
		{
			return indicator.WeeklyVWAP(Input, weeklyOpenTime, weeklyCloseTime);
		}

		public Indicators.MATE.MGI.YearlyMGI YearlyMGI(TimeSpan sessionStartTime, int yearsOfHistory, bool showPreviousYears, bool showPriorYearLevels, bool showPriorYearProfile, double valueAreaPercent, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			return indicator.YearlyMGI(Input, sessionStartTime, yearsOfHistory, showPreviousYears, showPriorYearLevels, showPriorYearProfile, valueAreaPercent, showLabels, showValues, labelDistance, lineWidth);
		}

		public Indicators.MATE.VWAP.YearlyVWAP YearlyVWAP(TimeSpan sessionStartTime)
		{
			return indicator.YearlyVWAP(Input, sessionStartTime);
		}


		
		public Indicators.MATE.Profiles.AnchoredVolumeProfile AnchoredVolumeProfile(ISeries<double> input )
		{
			return indicator.AnchoredVolumeProfile(input);
		}

		public Indicators.MATE.Tools.AuctionContext AuctionContext(ISeries<double> input , string rthTemplateName, bool manualTimesInEt, string rthStartText, string rthEndText, int ibMinutes, bool onStartsAtGlobexReopen, string globexOpenText, int lookback, bool useMedian, int minOnMinutes, int minRthMinutes, bool enableRotations, AcxRotationSequence rotationSequence, int rotationReversalTicks, bool showRotationDetail, bool enableDelta, bool enableCsvLog, bool enableAuditLog, bool showDataQuality, int panelFontSize, AcxPanelSide panelSide, bool showOvernightRange, bool showInitialBalanceRange, bool showRthRange, bool showEthRange, bool showRthVolume, bool showRelativeVolume, bool showOvernightVolume, bool showWeeklyRange, bool showWeeklyVolume, int weeksLookback, bool showOvernightInventory, bool showOvernightDelta, bool showIbExtensions, int panelRightMargin, int panelTopMargin)
		{
			return indicator.AuctionContext(input, rthTemplateName, manualTimesInEt, rthStartText, rthEndText, ibMinutes, onStartsAtGlobexReopen, globexOpenText, lookback, useMedian, minOnMinutes, minRthMinutes, enableRotations, rotationSequence, rotationReversalTicks, showRotationDetail, enableDelta, enableCsvLog, enableAuditLog, showDataQuality, panelFontSize, panelSide, showOvernightRange, showInitialBalanceRange, showRthRange, showEthRange, showRthVolume, showRelativeVolume, showOvernightVolume, showWeeklyRange, showWeeklyVolume, weeksLookback, showOvernightInventory, showOvernightDelta, showIbExtensions, panelRightMargin, panelTopMargin);
		}

		public Indicators.MATE.OrderFlow.BigTradesInstitutional BigTradesInstitutional(ISeries<double> input )
		{
			return indicator.BigTradesInstitutional(input);
		}

		public Indicators.MATE.MGI.DailyMGI DailyMGI(ISeries<double> input , TimeSpan rTHStartTime, TimeSpan rTHEndTime, TimeSpan overnightStartTime, TimeSpan overnightEndTime, TimeSpan eTHStartTime, TimeSpan eTHEndTime, int initialBalanceMinutes, int daysOfHistory, bool showPreviousDays, bool showOvernightRange, bool showInitialBalance, bool showIBExtensions, bool showPriorDayRTH, bool showPriorDayETH, bool showPriorDayProfile, bool showPriorETHProfile, bool showONProfile, double valueAreaPercent, bool showHalfGap, double iBExtensionMultiplier0, double iBExtensionMultiplier1, double iBExtensionMultiplier2, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			return indicator.DailyMGI(input, rTHStartTime, rTHEndTime, overnightStartTime, overnightEndTime, eTHStartTime, eTHEndTime, initialBalanceMinutes, daysOfHistory, showPreviousDays, showOvernightRange, showInitialBalance, showIBExtensions, showPriorDayRTH, showPriorDayETH, showPriorDayProfile, showPriorETHProfile, showONProfile, valueAreaPercent, showHalfGap, iBExtensionMultiplier0, iBExtensionMultiplier1, iBExtensionMultiplier2, showLabels, showValues, labelDistance, lineWidth);
		}

		public Indicators.MATE.VWAP.DailyVWAP DailyVWAP(ISeries<double> input , TimeSpan rTHStartTime, TimeSpan rTHEndTime, TimeSpan eTHStartTime, TimeSpan eTHEndTime)
		{
			return indicator.DailyVWAP(input, rTHStartTime, rTHEndTime, eTHStartTime, eTHEndTime);
		}

		public Indicators.MATE.OrderFlow.DeltaProfile DeltaProfile(ISeries<double> input )
		{
			return indicator.DeltaProfile(input);
		}

		public Indicators.MATE.OrderFlow.DeltaSuite DeltaSuite(ISeries<double> input , double bigTradeThreshold)
		{
			return indicator.DeltaSuite(input, bigTradeThreshold);
		}

		public Indicators.MATE.Profiles.FixedRangeVolumeProfile FixedRangeVolumeProfile(ISeries<double> input , int ticksPerRow)
		{
			return indicator.FixedRangeVolumeProfile(input, ticksPerRow);
		}

		public Indicators.MATE.OrderFlow.FootprintOrderFlow FootprintOrderFlow(ISeries<double> input )
		{
			return indicator.FootprintOrderFlow(input);
		}

		public Indicators.MATE.Tools.LagSentinel LagSentinel(ISeries<double> input , LagSentinelLocation location, int hOffset, int vOffset, double lagThresholdSeconds, double staleQuoteSeconds, double orderAckThresholdSeconds, double uiLagThresholdSeconds, int fontSize, bool alertOnDegraded, string alertSound)
		{
			return indicator.LagSentinel(input, location, hOffset, vOffset, lagThresholdSeconds, staleQuoteSeconds, orderAckThresholdSeconds, uiLagThresholdSeconds, fontSize, alertOnDegraded, alertSound);
		}

		public Indicators.MATE.OrderFlow.LiquidityHeatmap LiquidityHeatmap(ISeries<double> input , int rTHStartHHMM, bool bookmapMode, int snapshotIntervalSeconds, int maxHistoryMinutes, double maxHeatOpacity, double minVisibleOpacity, int heatmapMaxReference, bool filterSmallLiquidity, int minLiquidityThreshold, bool showActiveLiquidityExtension, bool showLastPriceLine, bool showHeatScale, bool showBestBidAskLines, bool showVolumeDots, int minDotVolume, int dotVolumeReference, int dotMaxRadius, double dotOpacity, bool showOrderBookPanel, int orderBookPanelWidth, bool showAbsorptionMarkers, int absorptionMinContracts, int absorptionWindowTicks, double icebergRatioThreshold, bool showPulledWallMarkers, int pulledWallMinContracts, int pulledWallMaxExecutedPct, double brokenMarkerFade, float absorptionMaxWidth, double absorptionMinOpacity, int refreshIntervalMs, int cleanupIntervalSeconds, int staleLevelMinutes, bool enableTelemetryLog)
		{
			return indicator.LiquidityHeatmap(input, rTHStartHHMM, bookmapMode, snapshotIntervalSeconds, maxHistoryMinutes, maxHeatOpacity, minVisibleOpacity, heatmapMaxReference, filterSmallLiquidity, minLiquidityThreshold, showActiveLiquidityExtension, showLastPriceLine, showHeatScale, showBestBidAskLines, showVolumeDots, minDotVolume, dotVolumeReference, dotMaxRadius, dotOpacity, showOrderBookPanel, orderBookPanelWidth, showAbsorptionMarkers, absorptionMinContracts, absorptionWindowTicks, icebergRatioThreshold, showPulledWallMarkers, pulledWallMinContracts, pulledWallMaxExecutedPct, brokenMarkerFade, absorptionMaxWidth, absorptionMinOpacity, refreshIntervalMs, cleanupIntervalSeconds, staleLevelMinutes, enableTelemetryLog);
		}

		public Indicators.MATE.MGI.MonthlyMGI MonthlyMGI(ISeries<double> input , TimeSpan sessionStartTime, int monthsOfHistory, bool showPreviousMonths, bool showPriorMonthLevels, bool showPriorMonthProfile, double valueAreaPercent, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			return indicator.MonthlyMGI(input, sessionStartTime, monthsOfHistory, showPreviousMonths, showPriorMonthLevels, showPriorMonthProfile, valueAreaPercent, showLabels, showValues, labelDistance, lineWidth);
		}

		public Indicators.MATE.VWAP.MonthlyVWAP MonthlyVWAP(ISeries<double> input , TimeSpan sessionStartTime)
		{
			return indicator.MonthlyVWAP(input, sessionStartTime);
		}

		public Indicators.MATE.MGI.QuarterlyMGI QuarterlyMGI(ISeries<double> input , TimeSpan sessionStartTime, int quartersOfHistory, bool showPreviousQuarters, bool showPriorQuarterLevels, bool showPriorQuarterProfile, double valueAreaPercent, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			return indicator.QuarterlyMGI(input, sessionStartTime, quartersOfHistory, showPreviousQuarters, showPriorQuarterLevels, showPriorQuarterProfile, valueAreaPercent, showLabels, showValues, labelDistance, lineWidth);
		}

		public Indicators.MATE.VWAP.QuarterlyVWAP QuarterlyVWAP(ISeries<double> input , TimeSpan sessionStartTime)
		{
			return indicator.QuarterlyVWAP(input, sessionStartTime);
		}

		public Indicators.MATE.Profiles.SessionTpoVolumeProfile SessionTpoVolumeProfile(ISeries<double> input , int ticksPerRow, int bracketMinutes, double valueAreaPercent, int minTailRows)
		{
			return indicator.SessionTpoVolumeProfile(input, ticksPerRow, bracketMinutes, valueAreaPercent, minTailRows);
		}

		public Indicators.MATE.MGI.WeeklyMGI WeeklyMGI(ISeries<double> input , TimeSpan weeklyOpenTime, TimeSpan weeklyCloseTime, int weeksOfHistory, bool showPreviousWeeks, bool showPriorWeekLevels, bool showPriorWeekProfile, double valueAreaPercent, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			return indicator.WeeklyMGI(input, weeklyOpenTime, weeklyCloseTime, weeksOfHistory, showPreviousWeeks, showPriorWeekLevels, showPriorWeekProfile, valueAreaPercent, showLabels, showValues, labelDistance, lineWidth);
		}

		public Indicators.MATE.VWAP.WeeklyVWAP WeeklyVWAP(ISeries<double> input , TimeSpan weeklyOpenTime, TimeSpan weeklyCloseTime)
		{
			return indicator.WeeklyVWAP(input, weeklyOpenTime, weeklyCloseTime);
		}

		public Indicators.MATE.MGI.YearlyMGI YearlyMGI(ISeries<double> input , TimeSpan sessionStartTime, int yearsOfHistory, bool showPreviousYears, bool showPriorYearLevels, bool showPriorYearProfile, double valueAreaPercent, bool showLabels, bool showValues, int labelDistance, int lineWidth)
		{
			return indicator.YearlyMGI(input, sessionStartTime, yearsOfHistory, showPreviousYears, showPriorYearLevels, showPriorYearProfile, valueAreaPercent, showLabels, showValues, labelDistance, lineWidth);
		}

		public Indicators.MATE.VWAP.YearlyVWAP YearlyVWAP(ISeries<double> input , TimeSpan sessionStartTime)
		{
			return indicator.YearlyVWAP(input, sessionStartTime);
		}

	}
}

#endregion
